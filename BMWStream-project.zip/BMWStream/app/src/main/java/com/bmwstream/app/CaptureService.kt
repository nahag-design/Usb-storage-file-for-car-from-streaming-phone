package com.bmwstream.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.getSystemService
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * Foreground service die audio opneemt die elders op het toestel wordt afgespeeld
 * (via AudioPlaybackCaptureConfiguration, Android 10+), en die bij het stoppen
 * omzet naar een MP3-bestand in Downloads.
 *
 * Belangrijke beperking om vooraf te weten: bronapps kunnen playback-capture
 * blokkeren (AudioAttributes.setAllowedCapturePolicy) en met DRM beveiligde
 * streams worden door Android sowieso uitgesloten van capture, ongeacht wat
 * deze app doet. Werkt het niet met een specifieke app/nummer, dan is dat de
 * oorzaak - geen bug in deze app.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.bmwstream.app.action.START"
        const val ACTION_STOP = "com.bmwstream.app.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "bmwstream_capture"
        private const val NOTIFICATION_ID = 1001

        private const val SAMPLE_RATE = 44100
        private const val CHANNELS = 2
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    private var pcmFile: File? = null
    private var bytesWritten: Long = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // Gebruiker heeft de systeem-toestemming ingetrokken; nette stop + opslaan.
            stopRecordingInternal(save = true, projectionAlreadyStopped = true)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> stopRecordingInternal(save = true, projectionAlreadyStopped = false)
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode != android.app.Activity.RESULT_OK || data == null) {
            CaptureBus.update { it.copy(errorMessage = "Kon audio-opname niet starten (geen toestemming).") }
            stopSelf()
            return
        }

        createNotificationChannel()
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            CaptureBus.update { it.copy(errorMessage = "Kon foreground-service niet starten: ${e.message}") }
            stopSelf()
            return
        }

        val projectionManager = getSystemService<MediaProjectionManager>()
        val projection = try {
            projectionManager?.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            null
        }

        if (projection == null) {
            CaptureBus.update { it.copy(errorMessage = "MediaProjection kon niet worden aangemaakt.") }
            finishService()
            return
        }

        mediaProjection = projection
        projection.registerCallback(projectionCallback, null)

        try {
            startAudioCapture(projection)
        } catch (e: SecurityException) {
            CaptureBus.update { it.copy(errorMessage = "Geen toestemming om audio op te nemen.") }
            finishService()
        } catch (e: Exception) {
            CaptureBus.update { it.copy(errorMessage = "Opname starten mislukt: ${e.message}") }
            finishService()
        }
    }

    private fun startAudioCapture(projection: MediaProjection) {
        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            CaptureBus.update { it.copy(errorMessage = "Audioformaat wordt niet ondersteund op dit toestel.") }
            finishService()
            return
        }
        val bufferSize = minBufferSize * 4

        val record = AudioRecord.Builder()
            .setAudioPlaybackCaptureConfig(config)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .build()

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            CaptureBus.update {
                it.copy(errorMessage = "Kan geen audio vastleggen: de bronapp staat opname niet toe, of speelt met DRM-beveiliging af.")
            }
            record.release()
            finishService()
            return
        }

        audioRecord = record
        val file = File(cacheDir, "capture_temp.pcm")
        pcmFile = file
        bytesWritten = 0L

        record.startRecording()
        CaptureBus.update {
            it.copy(isRecording = true, isEncoding = false, elapsedMs = 0L, lastSavedName = null)
        }

        recordingJob = serviceScope.launch {
            FileOutputStream(file, false).use { out ->
                val buffer = ByteArray(bufferSize)
                while (audioRecord != null) {
                    val current = audioRecord ?: break
                    val read = current.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        out.write(buffer, 0, read)
                        bytesWritten += read
                        val ms = (bytesWritten * 1000L) / (SAMPLE_RATE.toLong() * CHANNELS * BYTES_PER_SAMPLE)
                        CaptureBus.update { state -> state.copy(elapsedMs = ms) }
                    }
                }
            }
        }
    }

    private fun stopRecordingInternal(save: Boolean, projectionAlreadyStopped: Boolean) {
        val record = audioRecord
        audioRecord = null // laat de opnamelus stoppen

        try {
            record?.stop()
        } catch (_: Exception) {
            // kan gooien als recording al gestopt was; genegeerd
        }
        record?.release()

        if (!projectionAlreadyStopped) {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        }
        mediaProjection = null

        CaptureBus.update { it.copy(isRecording = false, isEncoding = save) }

        if (save && pcmFile != null && bytesWritten > 0) {
            serviceScope.launch {
                // korte marge zodat de opnamelus gegarandeerd klaar is met wegschrijven
                delay(300)
                encodeAndSave()
            }
        } else {
            finishService()
        }
    }

    private fun encodeAndSave() {
        val source = pcmFile
        if (source == null || !source.exists() || source.length() == 0L) {
            CaptureBus.update { it.copy(isEncoding = false, errorMessage = "Geen audio opgenomen.") }
            finishService()
            return
        }

        val tempMp3 = File(cacheDir, "capture_out_${System.currentTimeMillis()}.mp3")
        val command = "-y -f s16le -ar $SAMPLE_RATE -ac $CHANNELS -i \"${source.absolutePath}\" " +
            "-codec:a libmp3lame -qscale:a 2 \"${tempMp3.absolutePath}\""

        FFmpegKit.executeAsync(command) { session ->
            val ok = ReturnCode.isSuccess(session.returnCode) && tempMp3.exists() && tempMp3.length() > 0
            if (ok) {
                val savedName = saveToDownloads(tempMp3)
                tempMp3.delete()
                source.delete()
                if (savedName != null) {
                    CaptureBus.update { it.copy(isEncoding = false, lastSavedName = savedName) }
                } else {
                    CaptureBus.update {
                        it.copy(isEncoding = false, errorMessage = "Opslaan in Downloads is mislukt.")
                    }
                }
            } else {
                tempMp3.delete()
                CaptureBus.update {
                    it.copy(isEncoding = false, errorMessage = "Omzetten naar MP3 is mislukt.")
                }
            }
            finishService()
        }
    }

    /**
     * Slaat het gecodeerde bestand op als STREAM.MP3 in Downloads. Bestaat er al een
     * geldig (niet-leeg) STREAM.MP3-bestand, dan wordt een nieuw, uniek bestand
     * aangemaakt (STREAM_<tijdstip>.MP3) zodat een eerder geldig bestand nooit wordt
     * overschreven of beschadigd.
     */
    private fun saveToDownloads(source: File): String? {
        val resolver = contentResolver
        val targetName = if (existingValidStreamFileFound(resolver)) {
            "STREAM_${System.currentTimeMillis()}.MP3"
        } else {
            "STREAM.MP3"
        }

        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, targetName)
            put(MediaStore.Downloads.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null

        return try {
            resolver.openOutputStream(itemUri)?.use { out ->
                source.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Kon geen outputstream openen")

            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(itemUri, done, null, null)
            targetName
        } catch (e: Exception) {
            resolver.delete(itemUri, null, null)
            null
        }
    }

    private fun existingValidStreamFileFound(resolver: ContentResolver): Boolean {
        val projection = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.SIZE)
        val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ?"
        val args = arrayOf("STREAM.MP3")
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, args, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val sizeIndex = cursor.getColumnIndex(MediaStore.Downloads.SIZE)
                val size = if (sizeIndex >= 0) cursor.getLong(sizeIndex) else 0L
                return size > 0L
            }
        }
        return false
    }

    private fun finishService() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService<NotificationManager>()
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
