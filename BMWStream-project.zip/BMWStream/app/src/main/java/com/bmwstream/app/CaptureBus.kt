package com.bmwstream.app

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Status van de opname/omzetting, gedeeld tussen [CaptureService] en [MainActivity].
 * Omdat service en activity in hetzelfde proces draaien, gebruiken we hiervoor
 * een simpele in-process StateFlow in plaats van broadcasts of een bound service.
 */
data class CaptureUiState(
    val isRecording: Boolean = false,
    val isEncoding: Boolean = false,
    val elapsedMs: Long = 0L,
    val lastSavedName: String? = null,
    val errorMessage: String? = null
)

object CaptureBus {
    private val _state = MutableStateFlow(CaptureUiState())
    val state: StateFlow<CaptureUiState> = _state

    fun update(transform: (CaptureUiState) -> CaptureUiState) {
        _state.value = transform(_state.value)
    }
}
