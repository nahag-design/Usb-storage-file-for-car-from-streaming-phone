# BMW Stream — Fase 1

## Belangrijk: dit is broncode, geen kant-en-klare APK

Ik kon dit project **niet** in mijn eigen omgeving compileren: mijn sandbox heeft
geen internetverbinding en geen Android SDK/Gradle geïnstalleerd, dus ik kan geen
`.apk` bouwen of testen. Wat je hieronder krijgt is een **compleet, correct
opgezet Android Studio-project** — geen losse snippets, echt alle bestanden die
een werkende app nodig heeft — maar het bouwen zelf (Gradle sync + compileren)
moet jij op jouw eigen machine met Android Studio doen, omdat daar wél internet-
toegang is om de Kotlin/AndroidX/FFmpegKit-dependencies te downloaden.

Ik heb de code met zorg en op basis van de officiële Android-API's geschreven,
maar zonder echte build/test-cyclus kan ik "gegarandeerd nul compile-errors"
niet beloven. Kom je een fout tegen, plak 'm hier terug en ik los 'm direct op.

## Bouwen — optie A: gratis in de cloud, geen Android Studio nodig

Dit project bevat `.github/workflows/build.yml`, een gratis GitHub Actions-
workflow die de APK voor je compileert zonder dat je zelf iets hoeft te
installeren:

1. Maak (als je die nog niet hebt) een gratis account op github.com.
2. Maak een nieuwe, eventueel private, repository aan.
3. Upload de inhoud van deze map naar die repository (via de web-upload-knop
   kan ook, een git-repo is niet strikt nodig — sleep gewoon alle bestanden
   en mappen, inclusief de verborgen map `.github`, naar de upload-pagina).
4. Ga naar het tabblad **Actions** van je repository. De workflow "Build APK"
   start automatisch na de upload/push.
5. Wacht 3–5 minuten tot het groene vinkje verschijnt, open de run en download
   de APK onderaan bij **Artifacts** (`BMWStream-debug-apk`, een .zip met de
   .apk erin).
6. Zet de APK op je Pixel 9a en installeer 'm (zet eenmalig "installeren uit
   onbekende bron" aan voor de app waarmee je 'm opent).

Dit kost je niets — GitHub Actions is gratis voor persoonlijke repositories
binnen een ruime maandelijkse limiet, en deze build gebruikt daar maar een
fractie van.

## Bouwen — optie B: lokaal met Android Studio

1. Open de map `BMWStream/` in Android Studio (Giraffe of nieuwer).
2. Laat Android Studio de Gradle-sync draaien (dit downloadt automatisch de
   benodigde dependencies, waaronder de MP3-encoder, en regelt zelf een
   Gradle-wrapper — dit project bevat er zelf geen, zie hieronder).
3. Sluit je Pixel 9a aan (USB-debugging aan) of gebruik een emulator met
   Android 13+.
4. **Run** ▶️, of **Build > Build Bundle(s)/APK(s) > Build APK(s)** voor een
   installeerbaar bestand.

**Kanttekening:** dit project bevat geen `gradlew`/`gradle-wrapper.jar` — dat
kleine binaire bestand kon ik niet genereren zonder internettoegang. Android
Studio maakt er meestal automatisch een aan bij het openen van het project;
lukt dat niet, kies dan **File > Sync Project with Gradle Files** of maak zelf
een wrapper via **View > Tool Windows > Gradle > (project) > Tasks > wrapper**.

## Wat de app doet (fase 1)

- Vraagt netjes de benodigde permissies: `RECORD_AUDIO`, notificaties (Android
  13+), en de systeem-toestemming voor media-projection (het schermpje dat
  Android toont bij audio/scherm-capture — verplicht door Android zelf, dit
  kan geen enkele app overslaan).
- Start een **foreground service** die audio capteert die elders op de telefoon
  wordt afgespeeld (`AudioPlaybackCaptureConfiguration`, Android 10+), zodat de
  opname doorloopt ook als je naar Spotify/YouTube zelf overschakelt.
- Toont start/stop-knoppen en een live oplopende duratie-timer.
- Bij **Stop**: zet de opgenomen audio om naar een geldig MP3-bestand met de
  LAME-encoder (via een actief onderhouden voortzetting van FFmpegKit) en slaat
  het op als `STREAM.MP3` in de map **Downloads**.
- Bestaat er al een geldig, niet-leeg `STREAM.MP3`? Dan wordt een nieuw bestand
  met tijdstempel aangemaakt (`STREAM_<tijd>.MP3`) in plaats van het oude te
  overschrijven — zo raakt een eerder bestand nooit beschadigd.
- Duidelijke foutmeldingen als een bronapp opname blokkeert.

## Bekende beperking — belangrijk om te weten

Android's opname-API (`AudioPlaybackCaptureConfiguration`) kan **geen audio
capteren die met DRM is beveiligd**, en dat geldt systeembreed, ongeacht wat
deze app doet. Spotify streamt doorgaans DRM-beveiligde content. Concreet
betekent dit: het kan zijn dat de opname bij Spotify **leeg blijft of niet
start**, terwijl het bij YouTube (vaak geen DRM) of andere apps wél werkt. Dit
is een bewuste Android-systeembeperking, geen bug in deze app — er is geen
manier omheen zonder root/systeemwijzigingen.

## Fase 2 en verder (nog niet gebouwd)

Zoals afgesproken: eerst deze stabiele basis, daarna kunnen we kijken naar
near-real-time capture (encoderen terwijl er wordt opgenomen, i.p.v. pas bij
Stop) en pas daarna het complexere USB-live-stream-concept richting de CIC van
de BMW.
